

## Download files
### UCI household electricity dataset
```
curl -L -O -J https://archive.ics.uci.edu/ml/machine-learning-databases/00235/household_power_consumption.zip \
    -o data/household_power_consumption.zip
cd data
unzip household_power_consumption.zip
rm household_power_consumption.zip
```
